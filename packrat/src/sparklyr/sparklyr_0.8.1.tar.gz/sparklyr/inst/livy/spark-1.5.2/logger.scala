class Logger(role: String, id: Int) {
  def log(message: String) = {
  }

  def log(message: String, e: Exception) = {
  }

  def logError(message: String) = {
  }

  def logError(message: String, e: Exception) = {
  }

  def logWarning(message: String) = {
  }
}
