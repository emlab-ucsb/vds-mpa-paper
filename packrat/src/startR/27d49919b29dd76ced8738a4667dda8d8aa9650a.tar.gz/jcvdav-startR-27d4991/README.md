#test


## Repository structure 

```
-- DESCRIPTION
-- man
   |__create_dirs.Rd
   |__render_doc.Rd
   |__usual_suspects.Rd
-- NAMESPACE
-- R
   |__create_dirs.R
   |__create_readme.R
   |__render_doc.R
   |__usual_suspects.R
-- README.md
-- startR.Rproj
```

--------- 

<a href="https://orcid.org/0000-0003-1245-589X" target="orcid.widget" rel="noopener noreferrer" style="vertical-align:top;"><img src="https://orcid.org/sites/default/files/images/orcid_16x16.png" style="width:1em;margin-right:.5em;" alt="ORCID iD icon">orcid.org/0000-0003-1245-589X</a>
